# OIBSIP_Unit_Converter_Application_Task_1

Photo of working model with two parameters for conversion process
Main parameter choose:-
1)Lenght
2)Weight

Under Length:-
1)CentiMeter
2)MilliMeter
3)Meter
4)KiloMeter

Under Weight:-
1)KiloGram
2)Gram

![Task1](https://user-images.githubusercontent.com/90275875/215348351-db3511c0-660e-4f28-9353-467272e43e19.jpg)

